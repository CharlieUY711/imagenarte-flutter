import { useState, useRef, useEffect } from 'react';

type DimensionType = 'vertical' | 'square' | 'landscape' | 'circular' | null;

interface CropOverlayProps {
  dimension: DimensionType;
  containerWidth: number;
  containerHeight: number;
}

export function CropOverlay({ dimension, containerWidth, containerHeight }: CropOverlayProps) {
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [size, setSize] = useState({ width: 200, height: 200 });
  const [rotation, setRotation] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const startPosRef = useRef({ x: 0, y: 0 });
  const startMouseRef = useRef({ x: 0, y: 0 });

  const isCircular = dimension === 'circular';

  // Calcular tamaño inicial basado en la dimensión
  useEffect(() => {
    if (!containerWidth || !containerHeight) return;

    let newWidth = 200;
    let newHeight = 200;

    switch (dimension) {
      case 'vertical':
        newWidth = Math.min(containerWidth * 0.5, 200);
        newHeight = newWidth * 1.33; // 3:4
        break;
      case 'square':
        newWidth = Math.min(containerWidth * 0.5, containerHeight * 0.5, 200);
        newHeight = newWidth;
        break;
      case 'landscape':
        newHeight = Math.min(containerHeight * 0.5, 200);
        newWidth = newHeight * 1.33; // 4:3
        break;
      case 'circular':
        newWidth = Math.min(containerWidth * 0.5, containerHeight * 0.5, 200);
        newHeight = newWidth;
        break;
    }

    setSize({ width: newWidth, height: newHeight });
    
    // Centrar el recorte
    setPosition({
      x: (containerWidth - newWidth) / 2,
      y: (containerHeight - newHeight) / 2,
    });
  }, [dimension, containerWidth, containerHeight]);

  // Handlers de arrastre (para mover el área)
  const handlePointerDown = (e: React.PointerEvent) => {
    setIsDragging(true);
    startMouseRef.current = { x: e.clientX, y: e.clientY };
    startPosRef.current = { ...position };
    e.currentTarget.setPointerCapture(e.pointerId);
    e.stopPropagation();
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging) return;

    const deltaX = e.clientX - startMouseRef.current.x;
    const deltaY = e.clientY - startMouseRef.current.y;

    setPosition({
      x: startPosRef.current.x + deltaX,
      y: startPosRef.current.y + deltaY,
    });
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    if (!isDragging) return;
    setIsDragging(false);
    e.currentTarget.releasePointerCapture(e.pointerId);
  };

  return (
    <div className="absolute inset-0 pointer-events-none">
      {/* Overlay oscuro con recorte */}
      <div 
        className="absolute inset-0 bg-black/60 pointer-events-none"
        style={{
          clipPath: isCircular
            ? `polygon(0% 0%, 0% 100%, 100% 100%, 100% 0%, 0% 0%, 
                ${position.x + size.width / 2}px ${position.y}px,
                ${position.x + size.width / 2}px ${position.y}px)`
            : 'none',
        }}
      />

      {/* Área de recorte */}
      <div
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        className="absolute pointer-events-auto cursor-move"
        style={{
          left: `${position.x}px`,
          top: `${position.y}px`,
          width: `${size.width}px`,
          height: `${size.height}px`,
          transform: isCircular ? 'none' : `rotate(${rotation}deg)`,
          transformOrigin: 'center',
        }}
      >
        {/* Borde del área seleccionada */}
        <div
          className={`w-full h-full border-2 border-orange-500 ${
            isCircular ? 'rounded-full' : 'rounded-none'
          }`}
          style={{
            boxShadow: '0 0 0 9999px rgba(0, 0, 0, 0.6)',
          }}
        />

        {/* Puntos de esquina (solo para rectangulares) */}
        {!isCircular && (
          <>
            <div className="absolute -top-1 -left-1 w-3 h-3 bg-orange-500 rounded-full" />
            <div className="absolute -top-1 -right-1 w-3 h-3 bg-orange-500 rounded-full" />
            <div className="absolute -bottom-1 -left-1 w-3 h-3 bg-orange-500 rounded-full" />
            <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-orange-500 rounded-full" />
          </>
        )}
      </div>
    </div>
  );
}
