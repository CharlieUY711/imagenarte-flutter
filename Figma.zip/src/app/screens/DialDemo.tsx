import { useState, useRef, useEffect } from 'react';
import { ArrowLeft, Save, Move, RotateCw, Maximize2, Undo, SquareDashed, Hand, Image as ImageIcon, Video } from 'lucide-react';
import { DialButton } from '@/app/components/DialButton';
import { ClassicAdjustments, initialClassicAdjustments } from '@/app/components/ClassicAdjustments';
import { DimensionButton } from '@/app/components/DimensionButton';
import { ColorModeButton } from '@/app/components/ColorModeButton';
import { CropOverlay } from '@/app/components/CropOverlay';

interface DialDemoProps {
  imageUrl?: string;
  onImageSelect: (file: File) => void;
  onVideoSelect: (file: File) => void;
  onBack: () => void;
}

type ToolMode = 'select' | 'move' | 'scale' | 'rotate' | 'pointer' | 'undo' | null;
type ActiveControl = 'pixelate' | 'blur' | 'crop' | 'dimension' | 'adjustments' | null;

export function DialDemo({ imageUrl, onImageSelect, onVideoSelect, onBack }: DialDemoProps) {
  // DialButton individual states
  const [pixelateValue, setPixelateValue] = useState(0);
  const [blurValue, setBlurValue] = useState(0);
  const [cropValue, setCropValue] = useState(0);

  // ClassicAdjustments state
  const [classicAdjustments, setClassicAdjustments] = useState(initialClassicAdjustments);

  // DimensionButton state
  const [selectedDimension, setSelectedDimension] = useState<'vertical' | 'square' | 'landscape' | 'circular' | null>(null);
  const [dimensionPixels, setDimensionPixels] = useState(800);

  // ColorModeButton state
  const [selectedColorMode, setSelectedColorMode] = useState<'color' | 'grayscale' | 'sepia' | 'bw' | null>('color');

  // Tool mode state
  const [selectedTool, setSelectedTool] = useState<ToolMode>(null);

  // Control activo - solo uno a la vez
  const [activeControl, setActiveControl] = useState<ActiveControl>(null);
  const closeTimeoutRef = useRef<number | null>(null);

  // Auto-cerrar después de un delay
  const scheduleClose = () => {
    if (closeTimeoutRef.current) {
      clearTimeout(closeTimeoutRef.current);
    }
    closeTimeoutRef.current = window.setTimeout(() => {
      setActiveControl(null);
    }, 2000);
  };

  // Limpiar timeout al desmontar
  useEffect(() => {
    return () => {
      if (closeTimeoutRef.current) {
        clearTimeout(closeTimeoutRef.current);
      }
    };
  }, []);

  // Dimensiones del contenedor de imagen
  const [containerSize, setContainerSize] = useState({ width: 0, height: 0 });
  const containerRef = useRef<HTMLDivElement>(null);

  // Color predominante de la imagen
  const [dominantColor, setDominantColor] = useState('rgb(30, 30, 30)');
  const imageRef = useRef<HTMLImageElement>(null);

  // Refs para inputs de archivo
  const imageInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (containerRef.current) {
      const updateSize = () => {
        if (containerRef.current) {
          setContainerSize({
            width: containerRef.current.offsetWidth,
            height: containerRef.current.offsetHeight,
          });
        }
      };
      updateSize();
      window.addEventListener('resize', updateSize);
      return () => window.removeEventListener('resize', updateSize);
    }
  }, []);

  // Extraer color predominante de la imagen
  useEffect(() => {
    if (imageRef.current && imageRef.current.complete && imageUrl) {
      extractDominantColor();
    }
  }, [imageUrl]);

  const extractDominantColor = () => {
    if (!imageRef.current) return;

    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = imageRef.current.width;
    canvas.height = imageRef.current.height;
    ctx.drawImage(imageRef.current, 0, 0, canvas.width, canvas.height);

    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const data = imageData.data;

    let r = 0, g = 0, b = 0;
    const sampleSize = 10; // Muestrear cada 10 píxeles para performance

    for (let i = 0; i < data.length; i += 4 * sampleSize) {
      r += data[i];
      g += data[i + 1];
      b += data[i + 2];
    }

    const pixelCount = data.length / (4 * sampleSize);
    r = Math.floor(r / pixelCount);
    g = Math.floor(g / pixelCount);
    b = Math.floor(b / pixelCount);

    // Oscurecer un poco para fondo
    r = Math.floor(r * 0.3);
    g = Math.floor(g * 0.3);
    b = Math.floor(b * 0.3);

    setDominantColor(`rgb(${r}, ${g}, ${b})`);
  };

  const handleImageButtonClick = () => {
    imageInputRef.current?.click();
  };

  const handleVideoButtonClick = () => {
    videoInputRef.current?.click();
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onImageSelect(file);
    }
  };

  const handleVideoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onVideoSelect(file);
    }
  };

  const handleSave = () => {
    console.log('Guardando imagen con ajustes:', {
      pixelate: pixelateValue,
      blur: blurValue,
      crop: cropValue,
      dimension: selectedDimension,
      pixels: dimensionPixels,
      colorMode: selectedColorMode,
      adjustments: classicAdjustments,
    });
    alert('Imagen guardada (simulación)');
  };

  // Estado inicial: sin imagen cargada
  if (!imageUrl) {
    return (
      <div className="min-h-screen flex flex-col bg-black">
        {/* Header con logo y descripción */}
        <div className="pt-8 pb-4 px-6 text-center">
          <h1 className="text-white text-2xl font-light mb-2 tracking-wide">
            Imagen<span className="font-normal">@</span>rte
          </h1>
          <p className="text-gray-400 text-xs mb-1">
            Tratamiento y protección de imágenes
          </p>
          <p className="text-gray-500 text-xs">
            Versión MVP • Offline-first • Sin backend
          </p>
        </div>

        {/* Área gris oscuro con botones centrados */}
        <div className="flex-1 bg-neutral-900 flex items-center justify-center">
          <div className="flex flex-col gap-4">
            <button
              onClick={handleImageButtonClick}
              className="flex items-center gap-3 px-6 py-3 text-gray-400 hover:text-gray-200 transition-colors"
            >
              <ImageIcon className="w-5 h-5" />
              <span className="text-sm">Seleccionar imagen</span>
            </button>
            
            <button
              onClick={handleVideoButtonClick}
              className="flex items-center gap-3 px-6 py-3 text-gray-400 hover:text-gray-200 transition-colors"
            >
              <Video className="w-5 h-5" />
              <span className="text-sm">Seleccionar video</span>
            </button>
          </div>
        </div>

        {/* Inputs ocultos para selección de archivos */}
        <input
          ref={imageInputRef}
          type="file"
          accept="image/*"
          onChange={handleImageChange}
          className="hidden"
        />
        <input
          ref={videoInputRef}
          type="file"
          accept="video/*"
          onChange={handleVideoChange}
          className="hidden"
        />
      </div>
    );
  }

  // Estado con imagen: mostrar controles completos
  return (
    <div className="min-h-screen flex flex-col" style={{ backgroundColor: dominantColor }}>
      {/* Imagen con overlay de crop - pantalla completa */}
      <div 
        ref={containerRef}
        className="relative flex-1 overflow-hidden" 
      >
        <img 
          ref={imageRef}
          src={imageUrl} 
          alt="Imagen seleccionada" 
          className="w-full h-full object-cover"
          onLoad={extractDominantColor}
          crossOrigin="anonymous"
        />
        
        {selectedDimension && (
          <CropOverlay
            dimension={selectedDimension}
            containerWidth={containerSize.width}
            containerHeight={containerSize.height}
          />
        )}
      </div>

      {/* Herramientas - 6 filas con fondo de color predominante */}
      <div className="overflow-y-auto px-4 flex-shrink-0">
        {/* Barra de herramientas - arriba del primer botón */}
        <div className="w-full h-[25px] bg-orange-500 flex items-center justify-center gap-3 rounded-md">
          <button
            onClick={() => setSelectedTool(selectedTool === 'select' ? null : 'select')}
            className="flex items-center justify-center h-full px-2"
            title="Selección"
          >
            <SquareDashed className={`w-4 h-4 ${selectedTool === 'select' ? 'text-black' : 'text-white'}`} />
          </button>
          
          <button
            onClick={() => setSelectedTool(selectedTool === 'move' ? null : 'move')}
            className="flex items-center justify-center h-full px-2"
            title="Mover"
          >
            <Move className={`w-4 h-4 ${selectedTool === 'move' ? 'text-black' : 'text-white'}`} />
          </button>
          
          <button
            onClick={() => setSelectedTool(selectedTool === 'scale' ? null : 'scale')}
            className="flex items-center justify-center h-full px-2"
            title="Tamaño"
          >
            <Maximize2 className={`w-4 h-4 ${selectedTool === 'scale' ? 'text-black' : 'text-white'}`} />
          </button>
          
          <button
            onClick={() => setSelectedTool(selectedTool === 'rotate' ? null : 'rotate')}
            className="flex items-center justify-center h-full px-2"
            title="Girar"
          >
            <RotateCw className={`w-4 h-4 ${selectedTool === 'rotate' ? 'text-black' : 'text-white'}`} />
          </button>
          
          <button
            onClick={() => setSelectedTool(selectedTool === 'pointer' ? null : 'pointer')}
            className="flex items-center justify-center h-full px-2"
            title="Dedo"
          >
            <Hand className={`w-4 h-4 ${selectedTool === 'pointer' ? 'text-black' : 'text-white'}`} />
          </button>
          
          <button
            onClick={() => setSelectedTool(selectedTool === 'undo' ? null : 'undo')}
            className="flex items-center justify-center h-full px-2"
            title="Deshacer"
          >
            <Undo className={`w-4 h-4 ${selectedTool === 'undo' ? 'text-black' : 'text-white'}`} />
          </button>
        </div>

        <div className="space-y-2 mt-2">
          <DialButton
            label="Pixelar rostro"
            value={pixelateValue}
            onChange={(val) => {
              setPixelateValue(val);
              scheduleClose();
            }}
            active={activeControl === 'pixelate'}
            onActivate={() => setActiveControl('pixelate')}
          />

          <DialButton
            label="Blur selectivo"
            value={blurValue}
            onChange={(val) => {
              setBlurValue(val);
              scheduleClose();
            }}
            active={activeControl === 'blur'}
            onActivate={() => setActiveControl('blur')}
          />

          <DialButton
            label="Intensidad de crop"
            value={cropValue}
            onChange={(val) => {
              setCropValue(val);
              scheduleClose();
            }}
            active={activeControl === 'crop'}
            onActivate={() => setActiveControl('crop')}
          />

          <DimensionButton
            selectedDimension={selectedDimension}
            pixels={dimensionPixels}
            onDimensionChange={setSelectedDimension}
            onPixelsChange={(val) => {
              setDimensionPixels(val);
              scheduleClose();
            }}
            active={activeControl === 'dimension'}
            onActivate={() => setActiveControl('dimension')}
          />

          <ColorModeButton
            selectedMode={selectedColorMode}
            onChange={setSelectedColorMode}
          />

          <ClassicAdjustments
            values={classicAdjustments}
            onChange={(val) => {
              setClassicAdjustments(val);
              scheduleClose();
            }}
            active={activeControl === 'adjustments'}
            onActivate={() => setActiveControl('adjustments')}
          />
        </div>

        {/* Fila de botones Volver y Grabar */}
        <div className="grid grid-cols-2 gap-2 mt-2">
          <button
            onClick={onBack}
            className="flex items-center justify-center gap-1.5 rounded-md bg-orange-500 text-white hover:text-black active:text-black transition-colors h-[25px] px-2"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span className="text-xs font-medium">Volver</span>
          </button>
          
          <button
            onClick={handleSave}
            className="flex items-center justify-center gap-1.5 rounded-md bg-orange-500 text-white hover:text-black active:text-black transition-colors h-[25px] px-2"
          >
            <Save className="w-3.5 h-3.5" />
            <span className="text-xs font-medium">Grabar</span>
          </button>
        </div>
      </div>
    </div>
  );
}