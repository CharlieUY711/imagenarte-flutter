# Flujo de Navegación - Imagen@rte

## Diagrama de Flujo

```
┌─────────┐
│  HOME   │
└────┬────┘
     │ "Tratar imagen"
     ▼
┌─────────────────┐
│ WIZARD - PASO 1 │ Selección de imagen
│ (Elegir imagen) │
└────┬────────────┘
     │ "Siguiente"
     ▼
┌─────────────────┐
│ WIZARD - PASO 2 │ Acciones (toggles + sliders)
│  (Configurar)   │ - Pixelar rostro
└────┬────────────┘ - Blur selectivo
     │ "Siguiente" - Quitar fondo (disabled)
     ▼             - Crop inteligente
┌─────────────────┐
│ WIZARD - PASO 3 │ Vista previa + Resumen
│ (Confirmar)     │
└────┬────────────┘
     │ "Continuar a exportación"
     ▼
┌─────────────────┐
│     EXPORT      │ Formato, Calidad, Privacidad, Watermarks
│ (Exportar)      │
└────┬────────────┘
     │ "Exportar"
     ▼
┌─────────────────┐
│  SUCCESS ✓      │ Exportación lista
│ (Tratar otra)   │
└─────────────────┘
```

## Navegación hacia Atrás

En cada paso del Wizard y en Export:
- Botón `←` (flecha izquierda) en la esquina superior izquierda
- Vuelve al paso anterior sin perder datos

## Estados de Pantallas

### 1. HOME (Estado Inicial)
```
┌─────────────────────┐
│   Imagen@rte        │
│                     │
│ Tratamiento y       │
│ protección de       │
│ imágenes, sin nube. │
│                     │
│ [Tratar imagen]     │
│                     │
│ [Tratar video]      │
│ (próximamente)      │
└─────────────────────┘
```

### 2. WIZARD PASO 1 - Sin imagen
```
┌─────────────────────┐
│ ←  Paso 1 de 3      │
├─────────────────────┤
│ Seleccioná una      │
│ imagen              │
│                     │
│ ┌─────────────┐     │
│ │ Sin imagen  │     │
│ └─────────────┘     │
│                     │
│ [Elegir imagen]     │
│                     │
├─────────────────────┤
│ [Siguiente] (off)   │
└─────────────────────┘
```

### 3. WIZARD PASO 1 - Con imagen
```
┌─────────────────────┐
│ ←  Paso 1 de 3      │
├─────────────────────┤
│ Seleccioná una      │
│ imagen              │
│                     │
│ ┌─────────────┐     │
│ │   🖼️ IMG    │     │
│ └─────────────┘     │
│                     │
│ [Elegir imagen]     │
│                     │
├─────────────────────┤
│ [Siguiente] (on)    │
└─────────────────────┘
```

### 4. WIZARD PASO 2 - Todas las acciones OFF
```
┌─────────────────────┐
│ ←  Paso 2 de 3      │
├─────────────────────┤
│ Acciones            │
│                     │
│ ┌─────────────────┐ │
│ │ Pixelar rostro  │ │
│ │             OFF │ │
│ └─────────────────┘ │
│                     │
│ ┌─────────────────┐ │
│ │ Blur selectivo  │ │
│ │             OFF │ │
│ └─────────────────┘ │
│                     │
│ ┌─────────────────┐ │
│ │ Quitar fondo    │ │
│ │ (próximamente)  │ │
│ │         DISABLED│ │
│ └─────────────────┘ │
│                     │
│ ┌─────────────────┐ │
│ │ Crop inteligente│ │
│ │             OFF │ │
│ └─────────────────┘ │
│                     │
├─────────────────────┤
│ [Siguiente]         │
└─────────────────────┘
```

### 5. WIZARD PASO 2 - Pixelar ON
```
┌─────────────────────┐
│ ←  Paso 2 de 3      │
├─────────────────────┤
│ Acciones            │
│                     │
│ ┌─────────────────┐ │
│ │ Pixelar rostro  │ │
│ │              ON │ │
│ │                 │ │
│ │ Intensidad    7 │ │
│ │ ═══●═══════  │ │
│ │ 1         10    │ │
│ └─────────────────┘ │
│                     │
│ [...]               │
├─────────────────────┤
│ [Siguiente]         │
└─────────────────────┘
```

### 6. WIZARD PASO 2 - Crop ON
```
┌─────────────────────┐
│ ┌─────────────────┐ │
│ │ Crop inteligente│ │
│ │              ON │ │
│ │                 │ │
│ │ Aspecto         │ │
│ │ ┌─────────────┐ │ │
│ │ │ 16:9 (Horiz)│ │ │
│ │ └──────▼──────┘ │ │
│ └─────────────────┘ │
└─────────────────────┘
```

### 7. WIZARD PASO 3 - Sin acciones
```
┌─────────────────────┐
│ ←  Paso 3 de 3      │
├─────────────────────┤
│ Vista previa        │
│                     │
│ ┌─────────────┐     │
│ │   🖼️ IMG    │     │
│ └─────────────┘     │
│                     │
│ Vista previa. El    │
│ procesamiento final │
│ ocurre al exportar. │
│                     │
│ ┌─────────────────┐ │
│ │ Operaciones     │ │
│ │ activas         │ │
│ │                 │ │
│ │ No activaste    │ │
│ │ ninguna acción  │ │
│ │ (opcional).     │ │
│ └─────────────────┘ │
│                     │
├─────────────────────┤
│ [Continuar a        │
│  exportación]       │
└─────────────────────┘
```

### 8. WIZARD PASO 3 - Con acciones
```
┌─────────────────────┐
│ ┌─────────────────┐ │
│ │ Operaciones     │ │
│ │ activas         │ │
│ │                 │ │
│ │ • Pixelar rostro│ │
│ │   (intensidad 7)│ │
│ │ • Blur selectivo│ │
│ │   (intensidad 5)│ │
│ │ • Crop 16:9     │ │
│ └─────────────────┘ │
└─────────────────────┘
```

### 9. EXPORT - Estado inicial
```
┌─────────────────────┐
│ ←     Exportar      │
├─────────────────────┤
│ ┌─────────────┐     │
│ │ Procesando  │     │
│ │ vista       │     │
│ │ previa...   │     │
│ └─────────────┘     │
│                     │
│ ┌─────────────────┐ │
│ │ Formato y       │ │
│ │ calidad         │ │
│ │                 │ │
│ │ Formato         │ │
│ │ ┌───────────┐   │ │
│ │ │ JPG    ▼  │   │ │
│ │ └───────────┘   │ │
│ │                 │ │
│ │ Calidad      85 │ │
│ │ ═════●═════  │ │
│ │ 50       100    │ │
│ └─────────────────┘ │
│                     │
│ [...]               │
├─────────────────────┤
│ [Exportar]          │
└─────────────────────┘
```

### 10. EXPORT - Formato PNG
```
┌─────────────────────┐
│ ┌─────────────────┐ │
│ │ Formato y       │ │
│ │ calidad         │ │
│ │                 │ │
│ │ Formato         │ │
│ │ ┌───────────┐   │ │
│ │ │ PNG    ▼  │   │ │
│ │ └───────────┘   │ │
│ │                 │ │
│ │ PNG exporta sin │ │
│ │ pérdida.        │ │
│ └─────────────────┘ │
└─────────────────────┘
```

### 11. EXPORT - Sección Privacidad
```
┌─────────────────────┐
│ ┌─────────────────┐ │
│ │ Privacidad      │ │
│ │                 │ │
│ │ Limpiar metada- │ │
│ │ tos (EXIF)  ON  │ │
│ │                 │ │
│ │ Recomendado:    │ │
│ │ elimina infor-  │ │
│ │ mación que puede│ │
│ │ revelar detalles│ │
│ │ del dispositivo.│ │
│ └─────────────────┘ │
└─────────────────────┘
```

### 12. EXPORT - Watermarks OFF
```
┌─────────────────────┐
│ ┌─────────────────┐ │
│ │ Watermarks      │ │
│ │                 │ │
│ │ Watermark       │ │
│ │ visible    OFF  │ │
│ │                 │ │
│ │ Watermark invi- │ │
│ │ sible (básico)  │ │
│ │            OFF  │ │
│ └─────────────────┘ │
└─────────────────────┘
```

### 13. EXPORT - Watermark visible ON
```
┌─────────────────────┐
│ ┌─────────────────┐ │
│ │ Watermarks      │ │
│ │                 │ │
│ │ Watermark       │ │
│ │ visible     ON  │ │
│ │                 │ │
│ │ ┌─────────────┐ │ │
│ │ │ @mi_usuario │ │ │
│ │ └─────────────┘ │ │
│ └─────────────────┘ │
└─────────────────────┘
```

### 14. EXPORT - Watermark invisible ON + Comprobante
```
┌─────────────────────┐
│ ┌─────────────────┐ │
│ │ Watermark invi- │ │
│ │ sible (básico)  │ │
│ │             ON  │ │
│ │                 │ │
│ │ Agrega un token │ │
│ │ de verificación │ │
│ │ a la imagen.    │ │
│ │                 │ │
│ │ Exportar        │ │
│ │ comprobante ON  │ │
│ │                 │ │
│ │ Guarda un       │ │
│ │ manifest.json   │ │
│ │ para verifica-  │ │
│ │ ción local.     │ │
│ └─────────────────┘ │
└─────────────────────┘
```

### 15. EXPORT - Exportando
```
┌─────────────────────┐
│ ←     Exportar      │
├─────────────────────┤
│                     │
│ [...]               │
│                     │
├─────────────────────┤
│ [⌛ Exportando...]  │
└─────────────────────┘
```

### 16. SUCCESS - Exportación completa
```
┌─────────────────────┐
│                     │
│       ┌───┐         │
│       │ ✓ │         │
│       └───┘         │
│                     │
│ Exportación lista   │
│                     │
│ La imagen se guardó │
│ correctamente.      │
│                     │
│ [Tratar otra        │
│  imagen]            │
│                     │
└─────────────────────┘
```

## Convenciones de UI

### Botones
- `[Texto]` = Botón primario (negro con texto blanco)
- `[Texto] (off)` = Botón deshabilitado (gris claro)
- `[⌛ Texto...]` = Botón en estado loading (spinner)

### Toggles
- `OFF` = Toggle desactivado (gris)
- `ON` = Toggle activado (negro)
- `DISABLED` = Toggle deshabilitado (gris claro con opacidad)

### Sliders
- `═══●═══════` = Slider con handle en posición
- Número a la derecha = valor actual

### Dropdowns
- `[Texto ▼]` = Dropdown cerrado
- Al hacer click se abre menú con opciones

---

**Nota:** Este es un diagrama textual de referencia. El prototipo funcional tiene la UI completa con estilos, colores y elementos interactivos reales.
